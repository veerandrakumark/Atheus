/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cyber: {
          dark: '#0f172a',
          slate: '#1e293b',
          red: '#ef4444',
          cyan: '#06b6d4',
          amber: '#f59e0b',
        }
      }
    },
  },
  plugins: [],
}
