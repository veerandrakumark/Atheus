import React, { useState } from 'react';
import clsx from 'clsx';
import { Bot, Send, CheckCircle2 } from 'lucide-react';
import { chatCopilot } from '../services/api';

export default function ActionCenter({ dossier, actions }) {
  const [activeTab, setActiveTab] = useState('technical');
  const [query, setQuery] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [chatLoading, setChatLoading] = useState(false);

  const threatScore = dossier?.threat_score || 0;
  const severity = dossier?.severity || 'NONE';
  const mitreTactics = dossier?.mitre_tactics || [];
  
  const handleChat = async (q) => {
    if (!q.trim() || !dossier) return;
    
    setChatHistory(prev => [...prev, { role: 'user', content: q }]);
    setQuery('');
    setChatLoading(true);
    
    try {
      const res = await chatCopilot({ incident_id: dossier.incident_id, query: q });
      setChatHistory(prev => [...prev, { role: 'copilot', content: res.reply, cited: res.cited_events }]);
    } catch (err) {
      setChatHistory(prev => [...prev, { role: 'copilot', content: "Error communicating with AI Copilot." }]);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-cyber-slate rounded-lg border border-slate-700 overflow-hidden">
      {/* Header Info */}
      <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-800/50">
        <div className="flex items-center space-x-4">
          <div className="relative w-16 h-16 flex items-center justify-center rounded-full border-4 border-slate-700">
            <svg className="absolute inset-0 w-full h-full transform -rotate-90">
              <circle cx="28" cy="28" r="26" fill="transparent" strokeWidth="4" 
                className={clsx(
                  "transition-all duration-1000",
                  threatScore > 80 ? "stroke-cyber-red" : threatScore > 50 ? "stroke-cyber-amber" : "stroke-green-500"
                )}
                strokeDasharray="163" 
                strokeDashoffset={163 - (163 * threatScore) / 100}
              />
            </svg>
            <span className="text-xl font-bold">{threatScore}</span>
          </div>
          <div>
            <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Severity</div>
            <div className={clsx("text-lg font-bold", 
              severity === 'CRITICAL' ? 'text-cyber-red' : severity === 'HIGH' ? 'text-cyber-amber' : 'text-slate-300'
            )}>{severity}</div>
          </div>
        </div>
      </div>

      {/* MITRE Badges */}
      <div className="p-4 border-b border-slate-700">
        <div className="text-xs text-slate-400 font-bold mb-2">MITRE ATT&CK TTPs</div>
        <div className="flex flex-wrap gap-2">
          {mitreTactics.map((ttp, i) => (
            <span key={i} className="px-2 py-1 bg-slate-800 border border-slate-600 rounded text-xs text-slate-300 font-mono">
              {ttp}
            </span>
          ))}
          {mitreTactics.length === 0 && <span className="text-xs text-slate-500">No active threats detected.</span>}
        </div>
      </div>

      {/* Dual Lens Tabs */}
      <div className="flex border-b border-slate-700 bg-slate-900/50">
        <button 
          onClick={() => setActiveTab('technical')}
          className={clsx("flex-1 py-2 text-xs font-bold uppercase tracking-wider transition-colors", 
            activeTab === 'technical' ? "border-b-2 border-cyber-cyan text-cyber-cyan" : "text-slate-500 hover:text-slate-400")}
        >
          Technical Forensics
        </button>
        <button 
          onClick={() => setActiveTab('executive')}
          className={clsx("flex-1 py-2 text-xs font-bold uppercase tracking-wider transition-colors", 
            activeTab === 'executive' ? "border-b-2 border-cyber-cyan text-cyber-cyan" : "text-slate-500 hover:text-slate-400")}
        >
          Executive Brief
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 terminal-scroll text-sm">
        {activeTab === 'technical' ? (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-slate-300 mb-1">Attack Reconstruction</h3>
              <p className="text-slate-400 leading-relaxed">{dossier?.attack_story || "Awaiting telemetry analysis..."}</p>
            </div>
            {actions?.length > 0 && (
              <div className="mt-4 p-3 bg-black/40 rounded border border-slate-800 font-mono text-xs">
                <div className="text-cyber-cyan mb-2 border-b border-slate-800 pb-1">CONTAINMENT EXECUTION LOG</div>
                {actions.map((act, i) => (
                  <div key={i} className="flex items-center text-slate-300 mt-1">
                    <CheckCircle2 className="w-3 h-3 text-green-500 mr-2" />
                    <span className="opacity-70">[{new Date(act.timestamp).toLocaleTimeString()}]</span> 
                    <span className="ml-2">[EXECUTED] {act.action.replace('_', ' ')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <h3 className="font-bold text-slate-300 mb-1">Business Impact Summary</h3>
            <div className="p-3 bg-slate-800/50 rounded border border-slate-700">
              <div className="text-cyber-cyan font-bold mb-1">Estimated Liability Prevented</div>
              <div className="text-2xl font-bold text-white mb-3">$1.4M</div>
              <ul className="space-y-2 text-slate-400 list-disc list-inside">
                <li>Zero Production Data Exfiltrated</li>
                <li>Immediate Regulatory Compliance Maintained</li>
                <li>Business Continuity Preserved</li>
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Copilot Drawer */}
      <div className="border-t border-slate-700 bg-slate-900/80 p-4 flex flex-col h-1/3 min-h-[200px]">
        <div className="flex items-center text-xs text-cyber-cyan font-bold mb-2">
          <Bot className="w-4 h-4 mr-1" /> ATHEUS COPILOT
        </div>
        
        <div className="flex-1 overflow-y-auto terminal-scroll mb-2 space-y-2 text-xs">
          {chatHistory.map((msg, i) => (
            <div key={i} className={clsx("p-2 rounded border", msg.role === 'user' ? "bg-slate-800 border-slate-700 ml-4" : "bg-cyan-950/20 border-cyan-900/30 mr-4")}>
              <div className="font-bold mb-1 opacity-70">{msg.role === 'user' ? 'Analyst' : 'Copilot'}</div>
              <div>{msg.content}</div>
              {msg.cited && msg.cited.length > 0 && (
                <div className="mt-1 pt-1 border-t border-cyan-900/50 text-[10px] text-cyan-400">Cited: {msg.cited.join(', ')}</div>
              )}
            </div>
          ))}
          {chatLoading && <div className="text-cyan-500 animate-pulse">Analyzing...</div>}
        </div>

        <div className="flex space-x-2 overflow-x-auto terminal-scroll pb-2 mb-2">
          {["Why was host 10.0.1.10 isolated?", "What is the evidence for lateral movement?", "Explain the active honey-trap deployment."].map((q, i) => (
            <button key={i} onClick={() => handleChat(q)} className="shrink-0 px-2 py-1 bg-slate-800 border border-slate-700 hover:border-slate-500 rounded-full text-[10px] text-slate-300 whitespace-nowrap transition-colors">
              {q}
            </button>
          ))}
        </div>

        <div className="flex">
          <input 
            type="text" 
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleChat(query)}
            placeholder="Ask Copilot about the incident..."
            className="flex-1 bg-black border border-slate-700 rounded-l px-3 py-1.5 text-sm focus:outline-none focus:border-cyber-cyan"
            disabled={!dossier || chatLoading}
          />
          <button 
            onClick={() => handleChat(query)}
            disabled={!dossier || chatLoading}
            className="bg-cyber-cyan text-black px-3 rounded-r hover:bg-cyan-400 disabled:opacity-50 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
