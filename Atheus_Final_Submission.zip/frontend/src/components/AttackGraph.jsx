import React from 'react';
import clsx from 'clsx';
import { ShieldCheck, ShieldAlert, Target, Crosshair } from 'lucide-react';

export default function AttackGraph({ dossier, actions }) {
  const hasIncident = dossier != null;
  const isTrapActive = dossier?.deception_status === "TRAP_ACTIVE";
  const isolatedHosts = actions?.filter(a => a.action === "HOST_ISOLATION").map(a => a.target) || [];
  
  // Predict target
  const predicted = dossier?.predicted_target?.target || "";
  const isDbPredicted = predicted.includes("Active Directory") || predicted.includes("DB") || predicted.includes("Production");

  return (
    <div className="h-full bg-cyber-slate rounded-lg border border-slate-700 p-6 flex flex-col items-center justify-center relative overflow-hidden">
      <h2 className="absolute top-4 left-4 text-xs font-bold tracking-widest text-slate-400">NETWORK CANVAS</h2>
      
      {/* Node 1: Adversary */}
      <div className="mb-12 w-48 text-center p-3 rounded border border-cyber-red bg-red-950/20 relative z-10 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
        <div className="text-xs text-cyber-red font-bold mb-1 flex items-center justify-center"><Crosshair className="w-3 h-3 mr-1"/> Adversary</div>
        <div className="font-mono text-sm text-slate-300">198.51.100.23</div>
      </div>

      {/* SVG Connectors */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <defs>
          <marker id="arrow-red" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
            <path d="M0,0 L0,6 L9,3 z" fill="#ef4444" />
          </marker>
          <marker id="arrow-amber" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
            <path d="M0,0 L0,6 L9,3 z" fill="#f59e0b" />
          </marker>
          <marker id="arrow-slate" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
            <path d="M0,0 L0,6 L9,3 z" fill="#475569" />
          </marker>
        </defs>

        {/* Adv to Bastion */}
        <line x1="50%" y1="20%" x2="50%" y2="40%" stroke={hasIncident ? "#ef4444" : "#475569"} strokeWidth="2" markerEnd={`url(#arrow-${hasIncident ? 'red' : 'slate'})`} />
        
        {/* Bastion to HoneyDB */}
        <path d="M 50% 55% C 50% 65%, 25% 65%, 25% 75%" fill="none" stroke={isTrapActive ? "#f59e0b" : "#475569"} strokeWidth="2" strokeDasharray={isTrapActive ? "5,5" : "0"} markerEnd={`url(#arrow-${isTrapActive ? 'amber' : 'slate'})`} className={clsx(isTrapActive && "animate-pulse")} />
        
        {/* Bastion to Prod DB */}
        <path d="M 50% 55% C 50% 65%, 75% 65%, 75% 75%" fill="none" stroke={hasIncident && !isTrapActive ? "#ef4444" : "#475569"} strokeWidth="2" markerEnd={`url(#arrow-${hasIncident && !isTrapActive ? 'red' : 'slate'})`} />
      </svg>

      {/* Node 2: Bastion */}
      <div className={clsx(
        "mb-16 w-48 text-center p-3 rounded border z-10 transition-colors duration-500",
        isolatedHosts.includes("10.0.1.10") ? "border-cyan-500 bg-cyan-950/40" : (hasIncident ? "border-cyber-red animate-pulse bg-red-950/30" : "border-slate-600 bg-slate-800")
      )}>
        <div className="flex justify-between items-center mb-1">
          <div className="text-xs font-bold text-slate-300">Bastion Host</div>
          {isolatedHosts.includes("10.0.1.10") ? <ShieldCheck className="w-4 h-4 text-cyber-cyan" /> : (hasIncident && <ShieldAlert className="w-4 h-4 text-cyber-red" />)}
        </div>
        <div className="font-mono text-sm text-slate-400">10.0.1.10</div>
        {isolatedHosts.includes("10.0.1.10") && <div className="mt-2 text-[10px] text-cyber-cyan bg-cyan-900/50 px-2 py-1 rounded">ISOLATED & SECURED</div>}
      </div>

      <div className="flex w-full justify-around z-10">
        {/* Node 3: HoneyDB */}
        <div className={clsx(
          "w-48 text-center p-3 rounded border transition-all duration-500",
          isTrapActive ? "border-cyber-amber shadow-[0_0_20px_rgba(245,158,11,0.3)] bg-amber-950/30" : "border-slate-600 border-dashed bg-slate-800/50 opacity-50"
        )}>
          <div className="text-xs font-bold text-cyber-amber mb-1">HoneyDB Decoy</div>
          <div className="font-mono text-sm text-slate-400">10.0.2.99</div>
          {isTrapActive && <div className="mt-2 text-[10px] text-cyber-amber bg-amber-900/50 px-2 py-1 rounded">TRAP ACTIVE</div>}
        </div>

        {/* Node 4: Prod DB */}
        <div className={clsx(
          "w-48 text-center p-3 rounded border transition-all duration-500",
          !isTrapActive && hasIncident ? "border-cyber-red bg-red-950/30" : "border-slate-600 bg-slate-800",
          isDbPredicted && !isTrapActive ? "border-dashed border-amber-400" : ""
        )}>
           <div className="flex justify-between items-center mb-1">
            <div className="text-xs font-bold text-slate-300">Production DB</div>
            {isDbPredicted && !isTrapActive && <Target className="w-4 h-4 text-amber-400" />}
          </div>
          <div className="font-mono text-sm text-slate-400">10.0.2.45</div>
        </div>
      </div>
    </div>
  );
}
