import React, { useEffect, useRef } from 'react';
import clsx from 'clsx';
import { Terminal } from 'lucide-react';

export default function TelemetryTerminal({ events = [] }) {
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [events]);

  const getEventColor = (severity) => {
    if (severity >= 80) return "text-cyber-red border-cyber-red/20 bg-cyber-red/10";
    if (severity >= 50) return "text-cyber-amber border-cyber-amber/20 bg-cyber-amber/10";
    return "text-green-500 border-green-500/20 bg-green-500/5";
  };

  return (
    <div className="flex flex-col h-full bg-black rounded-lg border border-slate-800 overflow-hidden relative scanlines">
      <div className="bg-slate-900 px-4 py-2 flex items-center border-b border-slate-800 shrink-0">
        <Terminal className="w-4 h-4 text-slate-400 mr-2" />
        <span className="text-xs font-mono text-slate-400">telemetry_stream.log</span>
      </div>
      
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 font-mono text-sm terminal-scroll space-y-2"
      >
        {events.map((evt, idx) => {
          const colorClass = getEventColor(evt.severity_baseline);
          return (
            <div key={idx} className={clsx("p-2 border rounded", colorClass)}>
              <div className="flex justify-between items-start mb-1">
                <span className="opacity-80">[{new Date(evt.timestamp).toLocaleTimeString()}]</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold tracking-wider uppercase border border-current opacity-70">
                  {evt.source_type}
                </span>
              </div>
              <div className="font-bold mb-1">{evt.action}</div>
              <div className="text-xs opacity-70">
                {evt.source_ip} {evt.destination_ip ? `-> ${evt.destination_ip}` : ''}
              </div>
              <div className="text-xs opacity-50 mt-1 truncate">
                {JSON.stringify(evt.payload_meta)}
              </div>
            </div>
          );
        })}
        {events.length === 0 && (
          <div className="text-slate-600 flex items-center justify-center h-full">
            Waiting for telemetry...
          </div>
        )}
      </div>
    </div>
  );
}
