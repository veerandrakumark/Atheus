import React from 'react';
import { ShieldAlert, Activity, RefreshCw } from 'lucide-react';
import clsx from 'clsx';

export default function TopNav({ 
  autoMode, 
  setAutoMode, 
  onInject, 
  onReset, 
  loading 
}) {
  return (
    <div className="flex items-center justify-between p-4 bg-cyber-slate border-b border-slate-700">
      <div className="flex items-center space-x-3">
        <ShieldAlert className="text-cyber-cyan w-8 h-8" />
        <h1 className="text-xl font-bold tracking-widest text-white">ATHEUS <span className="text-slate-400 font-normal">// Autonomous Cyber Defense Engine</span></h1>
      </div>

      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2 bg-slate-900 px-4 py-1.5 rounded-full border border-green-900/50 shadow-[0_0_15px_rgba(34,197,94,0.2)]">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-sm font-medium text-green-400">ACTIVE DEFENSE ARMED</span>
        </div>

        <div className="flex items-center space-x-3">
          <span className="text-sm text-slate-300">Autonomous Mode</span>
          <button 
            onClick={() => setAutoMode(!autoMode)}
            className={clsx(
              "w-12 h-6 rounded-full transition-colors relative",
              autoMode ? "bg-cyber-cyan" : "bg-slate-600"
            )}
          >
            <div className={clsx(
              "w-4 h-4 bg-white rounded-full absolute top-1 transition-transform",
              autoMode ? "translate-x-7" : "translate-x-1"
            )}></div>
          </button>
        </div>

        <button 
          onClick={onReset}
          disabled={loading}
          className="flex items-center space-x-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-600 transition-colors"
        >
          <RefreshCw className={clsx("w-4 h-4", loading && "animate-spin")} />
          <span>Reset</span>
        </button>

        <button 
          onClick={onInject}
          disabled={loading}
          className="flex items-center space-x-2 px-5 py-2 bg-cyber-red hover:bg-red-600 text-white rounded font-bold transition-all shadow-[0_0_15px_rgba(239,68,68,0.4)] disabled:opacity-50 disabled:shadow-none"
        >
          <Activity className="w-4 h-4" />
          <span>Inject APT Attack Chain</span>
        </button>
      </div>
    </div>
  );
}
