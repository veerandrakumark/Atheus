from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.core.config import settings
from backend.app.api.v1 import api_router
from backend.app.models.domain import Base
from backend.app.db.session import engine

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Atheus",
    description="AI-Powered Autonomous Cybersecurity & Incident Investigation Platform",
    version="1.0.0",
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1")

@app.get("/health")
def health_check():
    return {"status": "healthy"}
